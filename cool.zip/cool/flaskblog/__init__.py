from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import LoginManager
from datetime import timedelta



app = Flask(__name__)
port=5000
app.config['SECRET_KEY'] = 'rt4w5v498nu45vesb'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['REMEMBER_COOKIE_DURATION'] = timedelta(seconds = 20)
app.config['FLASK_ADMIN_SWATCH'] = 'cerulean'

db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'Login'
login_manager.login_message_category ='danger'


from flask_admin import Admin
from flaskblog.models import God_Controller,User, Post, Button, Reaction,Comment

admin = Admin(app, name = "Admin-Mode" , template_mode='bootstrap3')
admin.add_view(God_Controller(User, db.session))
admin.add_view(God_Controller(Post, db.session))
admin.add_view(God_Controller(Comment, db.session))


from flaskblog import routes
