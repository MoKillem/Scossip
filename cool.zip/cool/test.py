from flaskblog import app, db
from flaskblog.models import User, Post, Button, Comment, Reaction
import unittest
from selenium import webdriver

class FlaskTestCodeStatus(unittest.TestCase):

    def test_loginCode(self): #check if login page is properly loaded
        tester = app.test_client(self)
        response = tester.get('/mainpage/login', content_type = 'html/text')
        self.assertEqual(response.status_code,302)#login page returns a redirect should give 302 code

    def test_mainpageCode(self):#check if mainpage is properly loaded
        tester = app.test_client(self)
        response = tester.get('/mainpage', content_type = 'html/text')
        self.assertEqual(response.status_code,200)#200 for ok

    def test_signupCode(self):#check if signup page is properly loaded
        tester = app.test_client(self)
        response = tester.get('/signup', content_type = 'html/text')
        self.assertEqual(response.status_code,200)#200 for ok
    
    def test_login(self):#test if login successful url directs to main page
        tester = app.test_client(self)
        response = tester.post('/mainpage/login', data =dict(email ='julietgrantham@gmail.com', password ='tttttttt'), follow_redirects=True)
        self.assertIn(b'Most funny', response.data)

    def test_loginError(self):#test if login unsuccessful url directs back to login
        tester = app.test_client(self)
        response = tester.post('/mainpage/login', data =dict(email ='julietgrantham@gmail.com', password ='wrongpassword'), follow_redirects=True)
        self.assertIn(b'Login', response.data)

    def test_signupEmailerror(self):#test signup with invalid email
        tester = app.test_client(self)
        response = tester.post('/signup', data =dict(first='Juliet', last ='Li', username='112233', email = '123', password = 'tttttttt', confirm = 'tttttttt', campus = 'crawley', description=''), follow_redirects=True)
        self.assertIn(b'Please enter your details', response.data)

    def test_signupUsernameError(self):#test with invalid user_name (username alr exist in database)
        tester = app.test_client(self)
        response = tester.post('/signup', data =dict(first='Juliet', last ='Li', username='Juliet', email = 'julietgrantham@gmail.com', password = 'tttttttt', confirm = 'tttttttt', campus = 'crawley', description=''), follow_redirects=True)
        self.assertIn(b'Please enter your details', response.data)

    def test_topDisplayLikes(self):#check most liked page
        tester = app.test_client(self)
        response = tester.get('/display_top/likes', content_type = 'html/text')
        self.assertIn(b'Most liked', response.data)

    def test_topDisplayshocks(self):#check most shocking page
        tester = app.test_client(self)
        response = tester.get('/display_top/shocks', content_type = 'html/text')
        self.assertIn(b'Most shocking', response.data)

    def test_topDisplaylaughs(self):#check most funny page
        tester = app.test_client(self)
        response = tester.get('/display_top/laughs', content_type = 'html/text')
        self.assertIn(b'Most funny', response.data)

    def test_topDisplaycomments(self):#check most commented page
        tester = app.test_client(self)
        response = tester.get('/display_top/comments', content_type = 'html/text')
        self.assertIn(b'Most commented', response.data)
    
    #the following code will give error but testokay
    def test_accountError(self): #wont be able to access account page without logging in
        tester = app.test_client(self)
        response = tester.get('/account', content_type = 'html/text')
        self.assertEqual(response.status_code, 500)#should give 500 

    def test_reactionError(self):#wont be able to react to the posts without logging in
        tester = app.test_client(self)
        response = tester.get('/reaction/1', content_type = 'html/text')
        self.assertEqual(response.status_code, 500)#should give 500

    def test_commentError(self):#wont be able to comment to the posts without logging in
        tester = app.test_client(self)
        response = tester.get('/comment/1', content_type = 'html/text')
        self.assertEqual(response.status_code, 500)#should give 500 error

    def test_newpostError(self):#wont be able to post new posts without logging in
        tester = app.test_client(self)
        response = tester.get('/post/new', content_type = 'html/text')
        self.assertEqual(response.status_code, 500)#should give 500 error

    def test_deletepostError(self):#wont be able to delete posts without logging in
        tester = app.test_client(self)
        response = tester.get('/delete/1', content_type = 'html/text')
        self.assertEqual(response.status_code, 500)#should give 500 error
        


'''
#the following code somwhow cant access localhost
class DatabaseTesting(unittest.TestCase):

    def setUp(self):
        self.app = app.test_client()
        db.create_all()
        user1 = User(first='Juliet', last ='Li',username='okayyouwrinnn', email = 'abcde@lalalala.com', password = 'tttttttt')
        user2 = User(first='Moe', last ='Bla',username='helpmdsfeee', email = 'Moe@testtttt.com', password = 'tttttttt')
        db.session.add(user1)
        db.session.add(user2)
        db.session.commit()
    
    def tearDown(self):
        user1 = User.query.filter_by(email = 'abcde@lalalala.com').first()
        db.session.delete(user1)
        db.session.delete(user2)
        db.drop_all()

    def test_post(self):
        user1 = User.query.filter_by(email = 'abcde@lalalala.com').first()
        post1 = Post(title='title',content='content',user=user1)
        db.session.add(post1)
        db.session.commit()
        post1 = Post.query.first()
        self.assertEqual(user1.posts[0].id, post1.id)

'''
'''
class FlaskTestDB(unittest.TestCase):
    driver = None

    def setUp(self):
        self.driver = webdriver.Chrome(executable_path='C:\\Users\\Administrator\\Desktop\\FaraxLugaDheerow\\chromedriver.exe')

        if not self.driver:
            self.skipTest('web browser not available')
        else:
            self.app = app.test_client()
            db.init_app(app)
            db.create_all()
            user1 = User(first='Juliet', last ='Li',username='killmeeeee', email = 'whyitisnotworking', password = 'tttttttt')
            user2 = User(first='Moe', last ='Bla',username='arhhhhhhh', email = 'Mmmmoe@test.com', password = 'tttttttt')
            db.session.add(user1)
            db.session.add(user2)
            db.session.commit()
            self.driver.maximize_window()
            self.driver.get('http://localhost:5000/')

    
    def tearDown(self):
        if self.driver:
            self.driver.close()
            user1 = User.query.filter_by(email = 'whyitisnotworking').first()
            user2 = User.query.filter_by(email = 'Mmmmoe@test.com').first()
            db.session.delete(user1)
            db.session.delete(user2)
            db.session.commit()


#    def test_signup(self):
#        self.driver.get('http://localhost:5000/signup')
#        self.driver.implicitly_wait(5)
#        form = self.driver.find_element_by_tag_name('form')

       



    def test_login(self):
        user1 = User.query.filter_by(email = 'whyitisnotworking').first()
        self.assertEqual(user1.first, 'Juliet', msg='user exists in database')
'''

if __name__ == "__main__":
    unittest.main()